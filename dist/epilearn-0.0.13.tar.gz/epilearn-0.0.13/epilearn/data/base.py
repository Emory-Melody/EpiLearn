
class Dataset():
    def __init__(   self,

                 ):
        pass

    def download(self):
        """Download selected files of the dataset."""

    def save(self):
        """Save current dataset."""

    def get_slice(self, timestamp):
        """Get a slice of graph or time series"""
    

