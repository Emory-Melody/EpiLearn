from .SIR import *
from . import (
    ARIMA,
    Dlinear,
    EINN,
    GRU,
    LSTM,
    XGB,
    CNN
)