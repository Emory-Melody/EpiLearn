from .GCN import GCN
from .GAT import GAT
from .SAGE import SAGE
from .GIN import GIN